# Master version for Pillow
__version__ = "10.1.0"
